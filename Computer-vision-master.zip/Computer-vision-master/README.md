
# Computer Vision with OpenCV Library using Python

It contains my work in OpenCV python.

## Requirements
 *    Python 2.7 or above
 *    Download OpenCV from opencv.org or from sourceforge.net
 *    Python numpy module. ( pip install numpy)
 *    install cv2 python library ( pip install cv2 )
 *    copy cv2.pyd from opencv\build\python\2.7\x86 to c:\python2.7\Lib\site-packages



